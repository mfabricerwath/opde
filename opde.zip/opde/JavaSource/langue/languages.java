package langue;

import java.io.Serializable;
import java.util.Locale;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@ViewScoped
public class languages implements Serializable{

	private static final long serialVersionUID = 1L;
    private static Locale locale=Locale.FRENCH;
	
	public Locale activerFrancais() {
		locale=Locale.FRENCH;
		FacesContext context = FacesContext.getCurrentInstance();
		context.getViewRoot().setLocale(locale);
		return locale;
		}
	public Locale activerAnglais() {
		locale=Locale.ENGLISH;
		FacesContext context = FacesContext.getCurrentInstance();
		context.getViewRoot().setLocale(locale);
		return locale;
		}
	
	public static Locale getLocale() {
		return locale;
	}
	public static void setLocale(Locale locale) {
		languages.locale = locale;
	}
	public Locale changeLanguage(){
		return locale;
		
	}
}
