package pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Actualitep implements Serializable{

	private static final long serialVersionUID = 1L;
    private int id;
    private String message,etat,entete;
    private boolean publie;
    private Date deadline;
    private Agentp agent;
    private List<Actualitep>liste,l;
    
	public Actualitep() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public boolean isPublie() {
		return publie;
	}

	public void setPublie(boolean publie) {
		this.publie = publie;
	}

	public Agentp getAgent() {
		return agent;
	}

	public void setAgent(Agentp agent) {
		this.agent = agent;
	}

	public List<Actualitep> getListe() {
		return liste;
	}

	public void setListe(List<Actualitep> liste) {
		this.liste = liste;
	}

	public String getEntete() {
		return entete;
	}

	public void setEntete(String entete) {
		this.entete = entete;
	}

	public Date getDeadline() {
		return deadline;
	}

	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}

	public List<Actualitep> getL() {
		return l;
	}

	public void setL(List<Actualitep> l) {
		this.l = l;
	}


    
}
