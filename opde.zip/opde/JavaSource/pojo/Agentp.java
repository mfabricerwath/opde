package pojo;

import java.io.Serializable;
import java.util.List;

public class Agentp implements Serializable{
    
	
	private static final long serialVersionUID = 1L;
    private int id;
    private String login,password,oldpassword,matricule,tel,profil,etatcivil,langue;
    private boolean candelete,cansave,canupdate;
    private Personnep personne;
    private List<Agentp>liste,l,deleted;
    
	public Agentp() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOldpassword() {
		return oldpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getProfil() {
		return profil;
	}

	public void setProfil(String profil) {
		this.profil = profil;
	}

	public String getEtatcivil() {
		return etatcivil;
	}

	public void setEtatcivil(String etatcivil) {
		this.etatcivil = etatcivil;
	}

	

	public Personnep getPersonne() {
		return personne;
	}

	public void setPersonne(Personnep personne) {
		this.personne = personne;
	}

	public boolean isCandelete() {
		return candelete;
	}

	public void setCandelete(boolean candelete) {
		this.candelete = candelete;
	}

	public boolean isCansave() {
		return cansave;
	}

	public void setCansave(boolean cansave) {
		this.cansave = cansave;
	}

	public boolean isCanupdate() {
		return canupdate;
	}

	public void setCanupdate(boolean canupdate) {
		this.canupdate = canupdate;
	}

	public List<Agentp> getListe() {
		return liste;
	}

	public void setListe(List<Agentp> liste) {
		this.liste = liste;
	}

	public String getLangue() {
		return langue;
	}

	public void setLangue(String langue) {
		this.langue = langue;
	}

	public List<Agentp> getL() {
		return l;
	}

	public void setL(List<Agentp> l) {
		this.l = l;
	}

	public List<Agentp> getDeleted() {
		return deleted;
	}

	public void setDeleted(List<Agentp> deleted) {
		this.deleted = deleted;
	}

}
