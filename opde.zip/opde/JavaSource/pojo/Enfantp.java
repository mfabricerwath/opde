package pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Enfantp implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private Personnep personne;
	private Agentp agentacceuillant, agent;
	private Famillep famille;
	private Date dateValidation,datePlacement;
	private String numIdentification, typeFormation,typeEducation,nomEcole, niveau,
			avisAgent,validationDirecteur, commentaireDirecteur;
	private boolean	ObservationFamille;
    private List<Enfantp>liste,l,deleted;
    
	public Enfantp() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Personnep getPersonne() {
		return personne;
	}

	public void setPersonne(Personnep personne) {
		this.personne = personne;
	}

	public Agentp getAgentacceuillant() {
		return agentacceuillant;
	}

	public void setAgentacceuillant(Agentp agentacceuillant) {
		this.agentacceuillant = agentacceuillant;
	}

	public Agentp getAgent() {
		return agent;
	}

	public void setAgent(Agentp agent) {
		this.agent = agent;
	}

	public Famillep getFamille() {
		return famille;
	}

	public void setFamille(Famillep famille) {
		this.famille = famille;
	}

	public String getNumIdentification() {
		return numIdentification;
	}

	public void setNumIdentification(String numIdentification) {
		this.numIdentification = numIdentification;
	}

	public String getTypeFormation() {
		return typeFormation;
	}

	public void setTypeFormation(String typeFormation) {
		this.typeFormation = typeFormation;
	}

	public String getNomEcole() {
		return nomEcole;
	}

	public void setNomEcole(String nomEcole) {
		this.nomEcole = nomEcole;
	}

	public String getNiveau() {
		return niveau;
	}

	public void setNiveau(String niveau) {
		this.niveau = niveau;
	}

	public String getAvisAgent() {
		return avisAgent;
	}

	public void setAvisAgent(String avisAgent) {
		this.avisAgent = avisAgent;
	}

	public String getValidationDirecteur() {
		return validationDirecteur;
	}

	public void setValidationDirecteur(String validationDirecteur) {
		this.validationDirecteur = validationDirecteur;
	}

	public String getCommentaireDirecteur() {
		return commentaireDirecteur;
	}

	public void setCommentaireDirecteur(String commentaireDirecteur) {
		this.commentaireDirecteur = commentaireDirecteur;
	}


	public Date getDateValidation() {
		return dateValidation;
	}

	public void setDateValidation(Date dateValidation) {
		this.dateValidation = dateValidation;
	}

	public Date getDatePlacement() {
		return datePlacement;
	}

	public void setDatePlacement(Date datePlacement) {
		this.datePlacement = datePlacement;
	}

	public String getTypeEducation() {
		return typeEducation;
	}

	public void setTypeEducation(String typeEducation) {
		this.typeEducation = typeEducation;
	}

	public boolean isObservationFamille() {
		return ObservationFamille;
	}

	public void setObservationFamille(boolean observationFamille) {
		ObservationFamille = observationFamille;
	}

	public List<Enfantp> getListe() {
		return liste;
	}

	public void setListe(List<Enfantp> liste) {
		this.liste = liste;
	}

	public List<Enfantp> getL() {
		return l;
	}

	public void setL(List<Enfantp> l) {
		this.l = l;
	}

	public List<Enfantp> getDeleted() {
		return deleted;
	}

	public void setDeleted(List<Enfantp> deleted) {
		this.deleted = deleted;
	}

}
