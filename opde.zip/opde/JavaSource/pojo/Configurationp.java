package pojo;

import java.io.Serializable;
import java.util.List;

public class Configurationp implements Serializable{
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
 private int id;
 private String prefixe,pour;
 private boolean parDefaut=false;
 private List<Configurationp>liste;
 
public Configurationp() {
	
	// TODO Auto-generated constructor stub
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getPrefixe() {
	return prefixe;
}

public void setPrefixe(String prefixe) {
	this.prefixe = prefixe;
}

public String getPour() {
	return pour;
}

public void setPour(String pour) {
	this.pour = pour;
}

public List<Configurationp> getListe() {
	return liste;
}

public void setListe(List<Configurationp> liste) {
	this.liste = liste;
}

public boolean isParDefaut() {
	return parDefaut;
}

public void setParDefaut(boolean parDefaut) {
	this.parDefaut = parDefaut;
}
 
 
}
