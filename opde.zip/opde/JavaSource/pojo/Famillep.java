package pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class Famillep implements Serializable{


	private static final long serialVersionUID = 1L;
    private int id;
    private String nom="";
    private List<Famillep>liste=new ArrayList<Famillep>();
    
	public Famillep() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public List<Famillep> getListe() {
		return liste;
	}

	public void setListe(List<Famillep> liste) {
		this.liste = liste;
	}


}
