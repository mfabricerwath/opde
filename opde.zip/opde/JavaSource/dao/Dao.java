package dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import controleur.Authentification;
import pojo.Actualitep;
import pojo.Agentp;
import pojo.Configurationp;
import pojo.Enfantp;
import pojo.Famillep;
import pojo.Personnep;

public class Dao {
	private static Dao dao;
	private static Connection con;

	private Dao() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/opde";
			try {
				con = DriverManager.getConnection(url, "root", "");
			 } catch (SQLException ex) {
				Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
			}
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Dao.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public static Dao getInstance() {
		if (dao == null) {
			dao = new Dao();
		}
		return dao;
	}

	public static Connection getCon() {
		return con;
	}

	public static void setCon(Connection con) {
		Dao.con = con;
	}

	public int getId(String table) {

		Statement stmt = null;
		ResultSet res = null;
		int id = 0;

		String sql = " SELECT max(id) as id FROM " + table;
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(sql);
			if (res.next()) {
				id = res.getInt("id");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return id + 1;
	}

	public boolean delete(String Table, int id) {

		boolean deleted = false;
		String req = "DELETE FROM " + Table + " WHERE id=?";
		try {
			PreparedStatement stmt = con.prepareStatement(req);
			stmt.setInt(1, id);

			if (stmt.executeUpdate() > 0) {
				deleted = true;
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return deleted;
	}
	
	public boolean archive(String Table, int id) {

		boolean deleted = false;
		String req = "UPDATE  " + Table + " set deleted='1' WHERE id=?";
		try {
			PreparedStatement stmt = con.prepareStatement(req);
			stmt.setInt(1, id);

			if (stmt.executeUpdate() > 0) {
				deleted = true;
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return deleted;
	}
	public boolean desarchive(String Table, int id) {

		boolean deleted = false;
		String req = "UPDATE  " + Table + " set deleted='0' WHERE id=?";
		try {
			PreparedStatement stmt = con.prepareStatement(req);
			stmt.setInt(1, id);

			if (stmt.executeUpdate() > 0) {
				deleted = true;
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return deleted;
	}

	public String dateaujour() {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
		return format.format(date);
	}
	public String aujourdhui() {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		return format.format(date);
	}
	public String numIdentification(String qui) {
		int num = 0;
		String retour="";
		Statement stmt = null;
		ResultSet res = null;
		String sql = " SELECT max(id) as id FROM personne";
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(sql);
			if (res.next()) {
				num = res.getInt("id") + 1;
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
         if(qui.equalsIgnoreCase("enfant"))
        	 retour=Prefixe()+""+num +"/"+dateaujour();
         else
        	 retour=PrefixeAgent()+""+num +"/"+dateaujour();
		return retour;
	}
	/************************* Personne *************************/
	private Personnep setPersonne(ResultSet rs) throws SQLException {

		Personnep e = new Personnep();
		e.setId(rs.getInt("id"));
		e.setNom(rs.getString("nom"));
		e.setPrenom(rs.getString("prenom"));
		e.setSexe(rs.getString("sexe"));
		e.setNationalite(rs.getString("nationalite"));
		e.setAdresse(rs.getString("adresse"));
		e.setLieudenaissance(rs.getString("lieudenaissance"));
		e.setDatenaissance(rs.getDate("datenaissance"));
		e.setImage(rs.getString("image"));

		return e;
	}

	public Personnep getPersonne(int id) {
		Personnep e = new Personnep();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM personne WHERE id=" + id);
			if (rs.next()) {
				e = setPersonne(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}

	private boolean insertPersonne(Personnep e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(getId("personne"));
		String sql = "INSERT INTO personne(id,nom,prenom,lieudenaissance,sexe,nationalite,adresse,datenaissance,image)"
				+ " VALUES (?,?,?,?,?,?,?,?,?)";

		try {

			stmt = con.prepareStatement(sql);

			stmt.setInt(1, e.getId());
			stmt.setString(2, e.getNom());
			stmt.setString(3, e.getPrenom());
			stmt.setString(4, e.getLieudenaissance());
			stmt.setString(5, e.getSexe());
			stmt.setString(6, e.getNationalite());
			stmt.setString(7, e.getAdresse());
			stmt.setObject(8, e.getDatenaissance());
			stmt.setString(9, e.getImage());
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updatePersonne(Personnep e) {

		boolean saved = false;
		PreparedStatement stmt = null;

		String sql = "UPDATE personne SET nom=?,prenom=?,lieudenaissance=?,sexe=?,nationalite=?,adresse=?,datenaissance=?,image=? WHERE id=?";

		try {
			stmt = con.prepareStatement(sql);
			stmt.setString(1, e.getNom());
			stmt.setString(2, e.getPrenom());
			stmt.setString(3, e.getLieudenaissance());
			stmt.setString(4, e.getSexe());
			stmt.setString(5, e.getNationalite());
			stmt.setString(6, e.getAdresse());
			stmt.setObject(7, e.getDatenaissance());
			stmt.setString(8, e.getImage());

			stmt.setInt(9, e.getId());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public boolean insertUpdatePersonne(Personnep e) {
		boolean saved = false;
		try {

			if (e.getId() == 0) {
				saved = insertPersonne(e);
			} else {
				saved = updatePersonne(e);
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	/************************* @finPersonne ************************/
	/**************************** Agent ***************************/
	private Agentp setAgent(ResultSet rs) throws SQLException {

		Agentp e = new Agentp();
		e.setId(rs.getInt("id"));
		e.setMatricule(rs.getString("matricule"));
		e.setPersonne(getPersonne(rs.getInt("id")));
		e.setEtatcivil(rs.getString("etatcivil"));
		e.setTel(rs.getString("tel"));
		e.setLogin(rs.getString("login"));
		e.setPassword(rs.getString("password"));
		e.setCandelete(rs.getBoolean("candelete"));
		e.setCansave(rs.getBoolean("cansave"));
		e.setCanupdate(rs.getBoolean("canupdate"));
		e.setLangue(rs.getString("langue"));
		e.setProfil(rs.getString("profil"));
		e.setLangue(rs.getString("langue"));
		return e;
	}

	public Agentp getAgent(int id) {
		Agentp e = new Agentp();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM agent WHERE id=" + id);
			if (rs.next()) {
				e = setAgent(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}
	
	public String PrefixeAgent(){
		String pre="";
		Statement stmt = null;
		ResultSet res = null;
		String sql = " SELECT prefixe from configuration where pour='agent' AND parDefaut='1'";
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(sql);
			if (res.next()) {
				pre= res.getString("prefixe");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return pre;
	}
	private boolean insertAgent(Agentp e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(e.getPersonne().getId());
		String sql = "INSERT INTO agent(id,matricule,etatcivil,tel,login,password,profil,candelete,cansave,canupdate,langue)"
				+ " VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		try {

			stmt = con.prepareStatement(sql);

			stmt.setInt(1, e.getId());
			stmt.setString(2, e.getMatricule());
			stmt.setString(3, e.getEtatcivil());
			stmt.setString(4, e.getTel());
			stmt.setString(5, e.getLogin());
			stmt.setString(6, crypt(e.getPassword()));
			stmt.setString(7, e.getProfil());
			stmt.setBoolean(8, e.isCandelete());
			stmt.setBoolean(9, e.isCansave());
			stmt.setBoolean(10, e.isCanupdate());
			stmt.setString(11, e.getLangue());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updateAgent(Agentp e) {

		boolean saved = false;
		PreparedStatement stmt = null;

		String sql = "UPDATE agent SET matricule=?,etatcivil=?,tel=?,login=?,password=?,profil=?,candelete=?,cansave=?,canupdate=?,langue=? WHERE id=?";

		try {
			stmt = con.prepareStatement(sql);

			stmt.setString(1, e.getMatricule());
			stmt.setString(2, e.getEtatcivil());
			stmt.setString(3, e.getTel());
			stmt.setString(4, e.getLogin());
			stmt.setString(5, crypt(e.getPassword()));
			stmt.setString(6, e.getProfil());
			stmt.setBoolean(7, e.isCandelete());
			stmt.setBoolean(8, e.isCansave());
			stmt.setBoolean(9, e.isCanupdate());
			stmt.setString(10, e.getLangue());
			stmt.setInt(11, e.getId());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public boolean deleteAgent(Agentp a) {
		boolean deleted = false;
		try {
			con.setAutoCommit(false);
			if (delete("agent", a.getId())) {
				deleted = true;
				if (deleted) {
					if (delete("personne", a.getPersonne().getId()))
						deleted = true;
				}
				if (deleted)
					con.commit();
				else
					con.rollback();
			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		return deleted;
	}

	public boolean insertUpdateAgent(Agentp e) {
		boolean saved = false;
		try {
			con.setAutoCommit(false);
			if (e.getPersonne().getId() == 0) {
				saved = insertPersonne(e.getPersonne());
				if (saved) {
					saved = insertAgent(e);
				}
			} else {
				saved = updatePersonne(e.getPersonne());
				if (saved) {
					saved = updateAgent(e);
				}
			}
			if (saved)
				con.commit();
			else
				con.rollback();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public List<Agentp> getAllAgent() {
		List<Agentp> c = new ArrayList<Agentp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT a.* FROM agent a,personne p WHERE a.id=p.id ORDER BY p.nom,p.prenom";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setAgent(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}
	public List<Agentp> getAllAgentliste() {
		List<Agentp> c = new ArrayList<Agentp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM agent where profil='agentSocial' AND deleted='0'";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setAgent(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}
	public List<Agentp> getAllAgentDeleted() {
		List<Agentp> c = new ArrayList<Agentp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM agent where profil='agentSocial' AND deleted='1'";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setAgent(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}

	public List<Agentp> listeTrieAgent(String  chaine) {
		List<Agentp> l = new ArrayList<Agentp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT e.* FROM agent e,personne p where e.id=p.id AND (e.matricule LIKE '"+chaine+"%' OR p.nom LIKE '"+chaine+"%' OR p.prenom LIKE '"+chaine+"%')  ORDER BY p.nom,p.prenom";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				l.add(setAgent(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return l;
	}

	public Agentp checkLogin(String login, String password) {

		Agentp selected = new Agentp();
		String req = "SELECT * FROM agent WHERE login=? AND password=?";
		PreparedStatement statement = null;
		ResultSet res = null;
		try {
			statement = con.prepareStatement(req);
			statement.setString(1, login);
			statement.setString(2, crypt(password));
			res = statement.executeQuery();
			if (res.next()) {
				selected = setAgent(res);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return selected;
	}

	public static String crypt(String key) {
		byte[] uniqueKey = key.getBytes();
		byte[] hash = null;
		try {
			hash = MessageDigest.getInstance("MD5").digest(uniqueKey);
		} catch (NoSuchAlgorithmException e) {
			throw new Error("no MD5 support in this VM");
		}
		StringBuffer hashString = new StringBuffer();
		for (int i = 0; i < hash.length; ++i) {
			String hex = Integer.toHexString(hash[i]);
			if (hex.length() == 1) {
				hashString.append('0');
				hashString.append(hex.charAt(hex.length() - 1));
			} else {
				hashString.append(hex.substring(hex.length() - 2));
			}
		}
		return hashString.toString();
	}

	public static boolean getcryptpass(String clearTextTestPassword,
			String encodedActualPassword) throws NoSuchAlgorithmException {
		String encodedTestPassword = crypt(clearTextTestPassword);
		return (encodedTestPassword.equals(encodedActualPassword));
	}

	/*************************** @finAgent ************************/
	/*************************** @DebutFamille ************************/
	private Famillep setFamille(ResultSet rs) throws SQLException {

		Famillep e = new Famillep();

		e.setId(rs.getInt("id"));
		e.setNom(rs.getString("nom"));

		return e;
	}

	public Famillep getFamille(int id) {

		Famillep e = new Famillep();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM famille WHERE id=" + id);
			if (rs.next()) {
				e = setFamille(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}

	private boolean insertFamille(Famillep e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(getId("famille"));
		String sql = "INSERT INTO famille(id,nom) VALUES (?,?)";

		try {
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, e.getId());
			stmt.setString(2, e.getNom());
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updateFamille(Famillep e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		String sql = "UPDATE famille SET nom=? WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);

			stmt.setString(1, e.getNom());
			stmt.setInt(2, e.getId());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public boolean insertUpdateFamille(Famillep b) {
		boolean saved = false;
		try {

			if (b.getId() == 0)
				saved = insertFamille(b);
			else
				saved = updateFamille(b);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public List<Famillep> getAllFamille() {
		List<Famillep> c = new ArrayList<Famillep>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM famille ";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setFamille(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}

	/*************************** @FinFamille ************************/
	/*************************** @Debut Enfant ************************/
	private Enfantp setEnfant(ResultSet rs) throws SQLException {

		Enfantp e = new Enfantp();
		e.setId(rs.getInt("id"));
		e.setNumIdentification(rs.getString("numIdentification"));
		e.setPersonne(getPersonne(rs.getInt("id")));
		e.setAgent(getAgent(rs.getInt("idAgent")));
		e.setNiveau(rs.getString("niveau"));
		e.setTypeFormation(rs.getString("typeFormation"));
		e.setTypeEducation(rs.getString("typeEducation"));
		e.setNomEcole(rs.getString("nomEcole"));
		e.setCommentaireDirecteur(rs.getString("commentaireDirecteur"));
		e.setAvisAgent(rs.getString("avisAgent"));
		e.setValidationDirecteur(rs.getString("validationDirecteur"));
		e.setDateValidation(rs.getDate("dateValidation"));
		e.setObservationFamille(rs.getBoolean("ObservationFamille"));
		e.setFamille(getFamille(rs.getInt("idFamille")));
		e.setAgentacceuillant(getAgent(rs.getInt("idAcceuillant")));
		e.setDatePlacement(rs.getDate("datePlacement"));

		return e;
	}

	
	public String Prefixe(){
		String pre="";
		Statement stmt = null;
		ResultSet res = null;
		String sql = " SELECT prefixe from configuration where pour='enfant' AND parDefaut='1'";
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(sql);
			if (res.next()) {
				pre= res.getString("prefixe");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return pre;
	}

	public Enfantp getEnfant(int id) {
		Enfantp e = new Enfantp();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM enfant WHERE id=" + id);
			if (rs.next()) {
				e = setEnfant(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}

	private boolean insertEnfant(Enfantp e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(getId("enfant"));
		String sql = "INSERT INTO enfant(id,numIdentification,idAgent,niveau,typeFormation,TypeEducation,nomEcole,idFamille)"
				+ " VALUES (?,?,?,?,?,?,?,?)";
		try {
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, e.getPersonne().getId());
			stmt.setString(2, e.getNumIdentification());
			stmt.setInt(3, e.getAgent().getId());
			stmt.setString(4, e.getNiveau());
			stmt.setString(5, e.getTypeFormation());
			stmt.setString(6, e.getTypeEducation());
			stmt.setString(7, e.getNomEcole());
			stmt.setInt(8,e.getFamille().getId());
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updateEnfant(Enfantp e) {
		boolean saved = false;
		PreparedStatement stmt = null;
		
		String sql = "UPDATE enfant SET numIdentification=?,idAgent=?,niveau=?,typeFormation=?,TypeEducation=?,nomEcole=?,idFamille=?  WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);
			
			stmt.setString(1, e.getNumIdentification());
			stmt.setInt(2, e.getAgent().getId());
			stmt.setString(3, e.getNiveau());
			stmt.setString(4, e.getTypeFormation());
			stmt.setString(5, e.getTypeEducation());
			stmt.setString(6, e.getNomEcole());
			stmt.setInt(7, e.getFamille().getId());
			stmt.setInt(8, e.getId());
			
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}
	public boolean updateEnfantParAgent(Enfantp e) {
		boolean saved = false;
		PreparedStatement stmt = null;
		
		String sql = "UPDATE enfant SET numIdentification=?,idAgent=?,niveau=?,typeFormation=?,TypeEducation=?,nomEcole=?,idFamille=?,avisAgent=?  WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);
			
			stmt.setString(1, e.getNumIdentification());
			stmt.setInt(2, e.getAgent().getId());
			stmt.setString(3, e.getNiveau());
			stmt.setString(4, e.getTypeFormation());
			stmt.setString(5, e.getTypeEducation());
			stmt.setString(6, e.getNomEcole());
			stmt.setInt(7, e.getFamille().getId());
			stmt.setString(8,e.getAvisAgent());
			stmt.setInt(9, e.getId());
			
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}
	
	public boolean updateEnfantParDirecteur(Enfantp e) {
		boolean saved = false;
		PreparedStatement stmt = null;
		
		String sql = "UPDATE enfant SET numIdentification=?,idAgent=?,niveau=?,typeFormation=?,TypeEducation=?,nomEcole=?,idFamille=?,avisAgent=?,commentaireDirecteur=?,validationDirecteur=?,dateValidation=now()  WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);
			
			stmt.setString(1, e.getNumIdentification());
			stmt.setInt(2, e.getAgent().getId());
			stmt.setString(3, e.getNiveau());
			stmt.setString(4, e.getTypeFormation());
			stmt.setString(5, e.getTypeEducation());
			stmt.setString(6, e.getNomEcole());
			stmt.setInt(7, e.getFamille().getId());
			stmt.setString(8,e.getAvisAgent());
			stmt.setString(9,e.getCommentaireDirecteur());
			stmt.setString(10,e.getValidationDirecteur());
			stmt.setInt(11, e.getId());
			
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}
	
	public boolean updateEnfantParAcceuillant(Enfantp e) {
		boolean saved = false;
		PreparedStatement stmt = null;
		
		String sql = "UPDATE enfant SET numIdentification=?,idAgent=?,niveau=?,typeFormation=?,TypeEducation=?,nomEcole=?,idFamille=?,ObservationFamille=?,idAcceuillant=?,datePlacement=now()  WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);
			
			stmt.setString(1, e.getNumIdentification());
			stmt.setInt(2, e.getAgent().getId());
			stmt.setString(3, e.getNiveau());
			stmt.setString(4, e.getTypeFormation());
			stmt.setString(5, e.getTypeEducation());
			stmt.setString(6, e.getNomEcole());
			stmt.setInt(7, e.getFamille().getId());
			stmt.setBoolean(8,e.isObservationFamille());
			stmt.setInt(9,e.getAgentacceuillant().getId());
			stmt.setInt(10, e.getId());
			
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public boolean deleteEnfant(Enfantp a) {
		boolean deleted = false;
		try {
			con.setAutoCommit(false);
			if (delete("enfant", a.getId())) {
				deleted = true;
				if (deleted) {
					if (delete("personne", a.getPersonne().getId()))
						deleted = true;
				}
				if (deleted)
					con.commit();
				else
					con.rollback();
			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		return deleted;
	}

	public boolean insertUpdateEnfant(Enfantp e) {
		boolean saved = false;
		try {
               con.setAutoCommit(false);
			if (e.getPersonne().getId() == 0) {
				saved = insertPersonne(e.getPersonne());
				if (saved) {
					saved = insertEnfant(e);
				}
			} else {
				saved = updatePersonne(e.getPersonne());
				if (saved) {
					
				if(Authentification.GetProperties().getProfil().equalsIgnoreCase("secretaire")){
					saved = updateEnfant(e);
				}
                if(Authentification.GetProperties().getProfil().equalsIgnoreCase("agentSocial")){
					saved=updateEnfantParAgent(e);
				}
                if(Authentification.GetProperties().getProfil().equalsIgnoreCase("directeurAdministratif")){
					saved=updateEnfantParDirecteur(e);
				}
                if(Authentification.GetProperties().getProfil().equalsIgnoreCase("familleAcceuil")){
					saved=updateEnfantParAcceuillant(e);
				}
			  } 
			}
			if (saved)
				con.commit();
			else
				con.rollback();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public List<Enfantp> getAllEnfant() {
		List<Enfantp> c = new ArrayList<Enfantp>();
		ResultSet r = null;
		Statement st = null;
		String sql = "SELECT a.* FROM enfant a,personne p WHERE a.id=p.id AND deleted='0' ORDER BY p.nom,p.prenom";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setEnfant(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}
	
	public List<Enfantp> getAllEnfantDeleted() {
		List<Enfantp> c = new ArrayList<Enfantp>();
		ResultSet r = null;
		Statement st = null;
		String sql = "SELECT a.* FROM enfant a,personne p WHERE a.id=p.id AND deleted='1' ORDER BY p.nom,p.prenom";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setEnfant(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}

	public List<Enfantp> listeTrieEnfant(String chaine) {
		List<Enfantp> l = new ArrayList<Enfantp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT e.* FROM enfant e,personne p where e.id=p.id AND (e.numIdentification LIKE '"+chaine+"%' OR p.nom LIKE '"+chaine+"%' OR p.prenom LIKE '"+chaine+"%') ORDER BY p.nom,p.prenom";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				l.add(setEnfant(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return l;
	}

	/*************************** @Fin Enfant ************************/
	/*************************** @DebutConfiguration ************************/
	private Configurationp setConfiguration(ResultSet rs) throws SQLException {

		Configurationp e = new Configurationp();

		e.setId(rs.getInt("id"));
		e.setPrefixe(rs.getString("prefixe"));
        e.setPour(rs.getString("pour"));
        e.setParDefaut(rs.getBoolean("parDefaut"));
		return e;
	}

	public Configurationp getConfiguration(int id) {

		Configurationp e = new Configurationp();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM configuration WHERE id=" + id);
			if (rs.next()) {
				e = setConfiguration(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}
    private boolean updatedefaut(Configurationp e){
    	boolean updated=false;
    	PreparedStatement stmt = null;
		String sql = "UPDATE configuration SET parDefaut=? WHERE id<>? AND parDefaut='1' AND pour='"+e.getPour()+"'";
		try {
			stmt = con.prepareStatement(sql);

			stmt.setBoolean(1,false);
			stmt.setInt(2, e.getId());

			stmt.execute();
			updated = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
    	return updated;
    }
	private boolean insertConfiguration(Configurationp e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(getId("configuration"));
		String sql = "INSERT INTO configuration(id,prefixe,pour,parDefaut) VALUES (?,?,?,?)";

		try {
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, e.getId());
			stmt.setString(2, e.getPrefixe());
			stmt.setString(3,e.getPour());
			stmt.setBoolean(4,e.isParDefaut());
			stmt.execute();
			saved = true;
            
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updateConfiguration(Configurationp e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		String sql = "UPDATE configuration SET prefixe=?,pour=?,parDefaut=? WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);

			stmt.setString(1, e.getPrefixe());
			stmt.setString(2,e.getPour());
			stmt.setBoolean(3,e.isParDefaut());
			stmt.setInt(4, e.getId());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}
  
	public boolean insertUpdateConfiguration(Configurationp b) {
		boolean saved = false;
		try {

			if (b.getId() == 0)
				saved = insertConfiguration(b);
			else
				saved = updateConfiguration(b);
            if(saved & b.isParDefaut()){
            	updatedefaut(b);
            }
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public List<Configurationp> getAllConfiguration() {
		List<Configurationp> c = new ArrayList<Configurationp>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM configuration ";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setConfiguration(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}
	/*************************** @Fin Configuration ************************/
	/*************************** @Debut actualite ************************/
	private Actualitep setActualite(ResultSet rs) throws SQLException {

		Actualitep e = new Actualitep();

		e.setId(rs.getInt("id"));
		e.setAgent(getAgent(rs.getInt("idAgent")));
		e.setEtat(rs.getString("etat"));
		e.setMessage(rs.getString("message"));
		e.setPublie(rs.getBoolean("publie"));
        e.setEntete(rs.getString("entete"));
        e.setDeadline(rs.getDate("deadline"));
		return e;
	}

	public Actualitep getActualite(int id) {

		Actualitep e = new Actualitep();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(" SELECT * FROM actualite WHERE id=" + id);
			if (rs.next()) {
				e = setActualite(rs);
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return e;
	}

	private boolean insertActualite(Actualitep e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		e.setId(getId("actualite"));
		String sql = "INSERT INTO actualite(id,message,etat,publie,idAgent,entete,deadline) VALUES (?,?,?,?,?,?,?)";

		try {
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, e.getId());
			stmt.setString(2, e.getMessage());
			stmt.setString(3,e.getEtat());
			stmt.setBoolean(4,e.isPublie());
			stmt.setInt(5,e.getAgent().getId());
			stmt.setString(6,e.getEntete());
			stmt.setObject(7,e.getDeadline());
			
			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	private boolean updateActualite(Actualitep e) {

		boolean saved = false;
		PreparedStatement stmt = null;
		String sql = "UPDATE actualite SET message=?,etat=?,publie=?,entete=?,deadline=? WHERE id=?";
		try {
			stmt = con.prepareStatement(sql);

			stmt.setString(1, e.getMessage());
			stmt.setString(2,e.getEtat());
			stmt.setBoolean(3,e.isPublie());
			stmt.setString(4,e.getEntete());
			stmt.setObject(5,e.getDeadline());
			stmt.setInt(6, e.getId());

			stmt.execute();
			saved = true;

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public boolean insertUpdateActualite(Actualitep b) {
		boolean saved = false;
		try {

			if (b.getId() == 0)
				saved = insertActualite(b);
			else
				saved = updateActualite(b);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return saved;
	}

	public List<Actualitep> getAllActualiteAll() {
		List<Actualitep> c = new ArrayList<Actualitep>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM actualite";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setActualite(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}
	public List<Actualitep> getAllActualite() {
		List<Actualitep> c = new ArrayList<Actualitep>();
		ResultSet r = null;
		Statement st = null;

		String sql = "SELECT * FROM actualite where  publie='1' AND deadline>='"+aujourdhui()+"' ";

		try {
			st = con.createStatement();
			r = st.executeQuery(sql);
			while (r.next()) {
				c.add(setActualite(r));
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return c;
	}

	/*************************** @FinActualite ************************/
}
